<?php

$server = "localhost";
$user = "root";
$password = "";
$nama_database = "tugas3_db";

$db = mysqli_connect($server, $user, $password, $nama_database);



?>